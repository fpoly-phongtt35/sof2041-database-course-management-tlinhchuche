USE EduSys
GO
-- Report: MANH - HOTEN -DIEM
CREATE PROC sp_BangDiem(@MaKH INT)
AS BEGIN
     SELECT
        nh.MaNH,
        nh.HoTen,
        hv.Diem
     FROM HocVien hv
         JOIN NguoiHoc nh ON nh.MaNH=hv.MaNH
     WHERE hv.MaKH = @MaKH
     ORDER BY hv.Diem DESC
 END
GO
-- Report : TEN_CD - SO_HV - THAP_NHAT - CAO_NHAT - TRUNGBINH
CREATE PROC sp_ThongKeDiem
 AS BEGIN
     SELECT
        TenCD ChuyenDe,
        COUNT (MaHV) SoHV,
        MIN (Diem) ThapNhat,
        MAX (Diem) CaoNhat,
        AVG (Diem) TrungBinh
     FROM KhoaHoc kh
        JOIN HocVien hv ON kh. MaKH=hv.MaKH
        JOIN ChuyenDe cd ON cd.MaCD=kh.MaCD
    GROUP BY TenCD
END
GO
 -- Report: TEN_CD-SO_KH - SO_HV - DOANH_THU - THAP_NHAT - CAO_NHAT - TRUNG_BINH
CREATE PROC sp_ThongKeDoanhThu (@Year INT)
AS BEGIN
     SELECT
         TenCD ChuyenDe,
         COUNT (DISTINCT kh.MaKH) SoKH,
         COUNT (hv.MaHV) SoHV,
        SUM(kh.HocPhi) DoanhThu,
         MIN (kh.HocPhi) ThapNhat,
         MAX (kh.HocPhi) CaoNhat,
         AVG (kh.HocPhi) TrungBinh
     FROM KhoaHoc kh
         JOIN HocVien hv ON kh.MaKH=hv.MaKH
         JOIN ChuyenDe cd ON cd.MaCD=kh.MaCD
     WHERE YEAR (NgayKG) = @Year
     GROUP BY TenCD
 END
GO
-- Report: NAM - SO_LUONG - DAU_TIEN - CUOI_CUNG
CREATE PROC sp_ThongKeNguoiHoc
AS BEGIN
    SELECT
        YEAR (NgayDK) Nam,
        COUNT (*) SoLuong,
        MIN (NgayDK) DauTien,
        MAX (NgayDK) CuoiCung
     FROM NguoiHoc
    GROUP BY YEAR (NgayDK)
 END





    
